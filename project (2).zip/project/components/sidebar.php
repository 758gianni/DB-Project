<?php $currentPage = basename($_SERVER['PHP_SELF']); ?>

<aside class="no-scrollbar fixed top-0 left-0 z-9999 h-screen w-[290px] flex flex-col border-r border-gray-200 bg-white overflow-y-auto transition-all duration-300 ease-in-out xl:static xl:translate-x-0">
    <div class="h-20 w-full mb-4 px-5 flex items-center justify-center border-gray-200 xl:border-b bg-white">
        <a href="index.php" class="select-none cursor-pointer flex items-center justify-center gap-2">
            <image class="h-6 w-auto mx-auto block" src="/images/logo.png" alt="MUC Logo" />
            <span class="sr-only">MUC, Database Project</span>
        </a>
    </div>

    <ul class="w-full mb-6 px-5 flex flex-col gap-1">
        <li>
            <a href="index.php" class="select-none cursor-pointer w-full px-4 py-3 inline-flex items-center justify-start gap-2 <?= $currentPage == 'index.php' ? 'text-blue-500' : 'text-gray-800' ?> transition-all duration-300 ease-in-out hover:opacity-80">
                <svg class="size-6" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <ellipse cx="12" cy="5" rx="9" ry="3"/>
                    <path d="M3 5V19A9 3 0 0 0 21 19V5"/>
                    <path d="M3 12A9 3 0 0 0 21 12"/>
                </svg>

                <span>Show Tables</span>
            </a>
        </li>

        <li>
            <a href="add-new-supplier.php" class="select-none cursor-pointer w-full px-4 py-3 inline-flex items-center justify-start gap-2 <?= $currentPage == 'add-new-supplier.php' ? 'text-blue-500' : 'text-gray-800' ?> transition-all duration-300 ease-in-out hover:opacity-80">
                <svg class="size-6" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <path d="M5 12h14" />
                    <path d="M12 5v14" />
                </svg>

                <span>Add New Supplier</span>
            </a>
        </li>

        <li>
            <a href="annual-parts-expenses.php" class="select-none cursor-pointer w-full px-4 py-3 inline-flex items-center justify-start gap-2 <?= $currentPage == 'annual-parts-expenses.php' ? 'text-blue-500' : 'text-gray-800' ?> transition-all duration-300 ease-in-out hover:opacity-80">
                <svg class="size-6" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <path d="M12 18H4a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5" />
                    <path d="m16 19 3 3 3-3" />
                    <path d="M18 12h.01" />
                    <path d="M19 16v6" />
                    <path d="M6 12h.01" />
                    <circle cx="12" cy="12" r="2" />
                </svg>

                <span>Annual Parts Expenses</span>
            </a>
        </li>

        <li>
            <a href="budget-projection.php" class="select-none cursor-pointer w-full px-4 py-3 inline-flex items-center justify-start gap-2 <?= $currentPage == 'budget-projection.php' ? 'text-blue-500' : 'text-gray-800' ?> transition-all duration-300 ease-in-out hover:opacity-80">
                <svg class="size-6" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <path d="M11 17h3v2a1 1 0 0 0 1 1h2a1 1 0 0 0 1-1v-3a3.16 3.16 0 0 0 2-2h1a1 1 0 0 0 1-1v-2a1 1 0 0 0-1-1h-1a5 5 0 0 0-2-4V3a4 4 0 0 0-3.2 1.6l-.3.4H11a6 6 0 0 0-6 6v1a5 5 0 0 0 2 4v3a1 1 0 0 0 1 1h2a1 1 0 0 0 1-1z" />
                    <path d="M16 10h.01" />
                    <path d="M2 8v1a2 2 0 0 0 2 2h1" />
                </svg>

                <span>Budget Projection</span>
            </a>
        </li>
    </ul>
</aside>
