#!/bin/bash
#
user="u66"
pass="Kitchen.Orderly.Write.Shake.35"
db="u66"
#
echo
#
mongoimport -d "$db" -c parts -u "$user" --password="$pass" --type="json" --file="parts_100.json" 
mongoexport -d "$db" -c parts -u "$user" -p "$pass" --type=csv --fields "_id,price,description" | tail -n +2 > parts.csv
#
echo "source parts_table.sql;" | mysql -u "$user" --password="$pass" "$db"
mysqlimport --fields-terminated-by=, --user="$user" --password="$pass" --local "$db" parts.csv
echo
