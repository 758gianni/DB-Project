#!/bin/bash
#          
user="u66"
pass="Kitchen.Orderly.Write.Shake.35"
db="u66"
#
echo
#
echo "db.parts.drop()" | mongo "$db" -u "$user" -p "$pass"
mongoimport -d "$db" -c parts -u "$user" --password="$pass" --type="json" --file="parts_100.json" 
mongoexport -d "$db" -c parts -u "$user" -p "$pass" --type=csv --fields "_id,price,description" | tail -n +2 > parts.csv
#
echo "source parts_table.sql;" | mysql -u "$user" --password="$pass" "$db"
cat parts.csv  | tr "," "\t" > parts.tsv
echo "load data local infile 'parts.tsv' into table parts fields terminated by '\t' (_id, price, description);" | mysql $db -u $user --password="$pass" --local-infile=1
echo
