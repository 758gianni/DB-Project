#!/bin/bash

user="u66"
pass="Kitchen.Orderly.Write.Shake.35"
db="u66"

# COUNTS
echo "SELECT COUNT(*) FROM parts;" | mysql "$db" -u "$user" --password="$pass"
echo "SELECT COUNT(*) FROM suppliers;" | mysql "$db" -u "$user" --password="$pass"
echo "SELECT COUNT(*) FROM supplier_phone_number;" | mysql "$db" -u "$user" --password="$pass"
echo "SELECT COUNT(*) FROM orders;" | mysql "$db" -u "$user" --password="$pass"
echo "SELECT COUNT(*) FROM order_part;" | mysql "$db" -u "$user" --password="$pass"

# SAMPLE DATA
echo "SELECT * FROM parts LIMIT 5;" | mysql "$db" -u "$user" --password="$pass"
echo "SELECT * FROM suppliers LIMIT 5;" | mysql "$db" -u "$user" --password="$pass"
echo "SELECT * FROM supplier_phone_number LIMIT 5;" | mysql "$db" -u "$user" --password="$pass"
echo "SELECT * FROM orders LIMIT 5;" | mysql "$db" -u "$user" --password="$pass"
echo "SELECT * FROM order_part LIMIT 5;" | mysql "$db" -u "$user" --password="$pass"

# ORDER -> PART COUNT
echo "
SELECT o._id, o.supp_id, COUNT(op.part_id) AS parts
FROM orders o
LEFT JOIN order_part op ON o._id = op.order_id
GROUP BY o._id, o.supp_id
LIMIT 5;
" | mysql "$db" -u "$user" --password="$pass"

# SUPPLIER -> PHONE COUNT
echo "
SELECT s._id, s.name, COUNT(sp._id) AS phone_count
FROM suppliers s
LEFT JOIN supplier_phone_number sp ON s._id = sp.supp_id
GROUP BY s._id, s.name
LIMIT 5;
" | mysql "$db" -u "$user" --password="$pass"

# DELETE TABLES AND START FRESH
# mysql -u u66 --password="Kitchen.Orderly.Write.Shake.35" u66 -e "
# SET FOREIGN_KEY_CHECKS=0;
# DROP TABLE IF EXISTS order_part, orders, supplier_phone_number, suppliers, parts;
# SET FOREIGN_KEY_CHECKS=1;
# "

# SHOW TABLES
# mysql -u u66 --password="Kitchen.Orderly.Write.Shake.35" u66 -e "SHOW TABLES;"

# CREATE DATABASE TABLES
# bash j2sql_parts2.sh ; bash j2sql_supp+order.sh

# START PROJECT
# cd PROJECT ; php -S localhost:3000 

