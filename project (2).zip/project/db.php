<?php

$env = parse_ini_file('.env');

$DB_USER = $env['DB_USER'];
$DB_PASS = $env['DB_PASS'];

define('DB_HOST', 'localhost');
define('DB_USER', $DB_USER);
define('DB_PASS', $DB_PASS);
define('DB_NAME', $DB_USER);

$conn = mysqli_connect(DB_HOST, DB_USER, DB_PASS, DB_NAME);
    
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
